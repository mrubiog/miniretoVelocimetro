//Micaías Rubio

import UIKit

enum Velocidades : Int{
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    init(velocidadInicial : Velocidades){
        self = velocidadInicial
    }
    
}

class Auto {
    var velocidad : Velocidades
    init() {
        velocidad = Velocidades(velocidadInicial : .Apagado)
    }
    
    func cambioDeVelocidad() -> (actual : Int, velocidadEnCadena: String){
        let actual = velocidad.rawValue
        var cadena = ""
        
        switch velocidad {
        case .Apagado:
            velocidad = .VelocidadBaja
            cadena = "Apagado"
        case .VelocidadBaja:
            velocidad = .VelocidadMedia
            cadena = "Velocidad Baja"
        case .VelocidadMedia:
            velocidad = .VelocidadAlta
            cadena = "Velocidad Media"
        case .VelocidadAlta:
            velocidad = .Apagado
            cadena = "Velocidad Alta"
        }
        return (actual, cadena)
    }
    
}

let auto = Auto()
for i in 1...20 {
    let result = auto.cambioDeVelocidad()
    print("\(result.actual), \(result.velocidadEnCadena)")
}




